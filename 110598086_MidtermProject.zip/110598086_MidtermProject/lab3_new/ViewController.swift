//
//  ViewController.swift
//  lab3_new
//
//  Created by student on 2022/3/21.
//  Copyright © 2022年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var inputLabel: UILabel!
    
    @IBOutlet var numButton: [UIButton]!
    @IBOutlet var ope: [UIButton]!
    @IBOutlet var chara: [UIButton]!
    
    //let funct:String = ""
    //let fucctTem:String = ""
    
    var numArray = [Float]()
    var strArray = [String]()
    var opeArray = [Character]()
    var opeArrayS = [Character]()
    let charaArray:CharacterSet = ["+","-","x","/"]
    
    var numChoice = ["0","1","2","3","4","5","6","7","8","9","."]
    var opeChoice = ["=","+","-","x","/"]
    
    let count:Float = 0
    
    var previous:String = "init"
    var buttonTag:Int = -1
    var divZero:Bool = false
    var p_or_n:Bool = false
    
    
    @IBAction func numInput(_ sender: UIButton) {
        let buttonNumber = numButton.index(of: sender)
        
        if sender.currentTitle == numChoice[buttonNumber!] {
            if sender.currentTitle == "0"{
                
                if numCount.count > 0 {
                    if numCount[numCount.index(before: numCount.endIndex)] != "+"
                        && numCount[numCount.index(before: numCount.endIndex)] != "-"
                        && numCount[numCount.index(before: numCount.endIndex)] != "x"
                        && numCount[numCount.index(before: numCount.endIndex)] != "/"{
                            numCount += "0"
                            previous = "0"
                    }else if numCount[numCount.index(before: numCount.endIndex)] == "/"{
                        numCount += "0"
                        divZero = true
                    }
                }
                
                //print(numCount[numCount.index(before: numCount.endIndex)])
                
            }else if sender.currentTitle == "."{
                if previous != "." && numCount.count > 0 && numCount[numCount.index(before: numCount.endIndex)] != "+"
                && numCount[numCount.index(before: numCount.endIndex)] != "-"
                && numCount[numCount.index(before: numCount.endIndex)] != "x"
                && numCount[numCount.index(before: numCount.endIndex)] != "/" {
                    previous = "."
                    numCount += "."
                    //print(numCount)
                }
            }else{
                previous = sender.currentTitle!
                numCount += numChoice[buttonNumber!]
            }
        }
        
        buttonHighlight(sender.tag)
    }
    
    @IBAction func opeInput(_ sender: UIButton) {
        buttonHighlight(sender.tag)
        
        
        if sender.currentTitle != "=" {
            if numCount.count == 0{
                numCount += "0"
            }
            if previous == "+" || previous == "-" || previous == "x" || previous == "/"{
                numCount.remove(at: numCount.index(before: numCount.endIndex))
                numCount += sender.currentTitle!
            }else{
                numCount += sender.currentTitle!
            }
            
            
            
        }else{
            chara[0].setTitle("AC", for: .normal)
            if divZero == true {
                total = "0"
                
            }else{
            
            strArray = numCount.components(separatedBy: charaArray)
            for index in strArray.indices {
                numArray.append(Float(strArray[index])!)
            }
            
            for index in numCount.indices {
                switch numCount[index] {
                case "+":
                    opeArray.append("+")
                    break
                case "-":
                    opeArray.append("-")
                    break
                case "x":
                    opeArray.append("x")
                    break
                case "/":
                    opeArray.append("/")
                    break
                default:
                    break
                }
            }
                
            //print(numArray)
            var temStr:String = ""
            for index in opeArray.indices{
                temStr += removeZero(String(numArray[index]))
                temStr += removeZero(String(opeArray[index]))
            }
            temStr += removeZero(String(numArray[numArray.endIndex - 1]))
                
                
            for index in opeArray.indices{
                if opeArray[index] == "x"{
                    numArray[index] = numArray[index] * numArray[index + 1]
                    numArray[index + 1] = 0.0
                    opeArray[index] = "+"
                }else if opeArray[index] == "/" {
                    numArray[index] = numArray[index] / numArray[index + 1]
                    numArray[index + 1] = 0.0
                    opeArray[index] = "+"
                }
            }
            
            for index in opeArray.indices{
                if opeArray[index] == "+"{
                    numArray[index + 1] = numArray[index] + numArray[index + 1]
                }else if opeArray[index] == "-" {
                    numArray[index + 1] = numArray[index] - numArray[index + 1]
                }
            }
            
            total = String(numArray[numArray.endIndex - 1])
            total = removeZero(total)
            //print(numArray)
            numCount = temStr
            }
        }
        
        
        previous = sender.currentTitle!
    }
    
    @IBAction func charaInput(_ sender: UIButton) {
        
        if sender.currentTitle == "C" {
            if(numCount.count > 1){
                if previous != "+" && previous != "-" && previous != "x" && previous != "/" {
                    numCount.remove(at: numCount.index(before: numCount.endIndex))
                    previous = String(numCount[numCount.index(before: numCount.endIndex)])
                }
                if previous == "+" || previous == "-" || previous == "x" || previous == "/"{
                    chara[0].setTitle("AC", for: .normal)
                }
            }else{
                numCount = ""
                previous = "init"
            }
            
            
            
        }else if sender.currentTitle == "AC"{
            numCount = ""
            total = "0"
            numArray = [Float]()
            strArray = [String]()
            opeArray = [Character]()
            opeArrayS = [Character]()
            divZero = false
            chara[0].setTitle("C", for: .normal)
            previous = "init"
        }else if sender.currentTitle == "+/-"{
            if numCount.count == 0{
                numCount += "0"
            }
            if p_or_n == false{
                if previous == "+" || previous == "-" || previous == "x" || previous == "/"{
                    numCount.remove(at: numCount.index(before: numCount.endIndex))
                    numCount += "-"
                }else{
                    numCount += "-"
                }
                p_or_n = true
                previous = "-"
            }else{
                if previous == "+" || previous == "-" || previous == "x" || previous == "/"{
                    numCount.remove(at: numCount.index(before: numCount.endIndex))
                    numCount += "+"
                }else{
                    numCount += "+"
                }
                p_or_n = false
                previous = "+"
            }
        }else if sender.currentTitle == "%"{
            strArray = numCount.components(separatedBy: charaArray)
            numArray.append(Float(strArray[0])!)
            total = removeZero(String(numArray[0] / 100))
            chara[0].setTitle("AC", for: .normal)
            
        }
        
        buttonHighlightP(previous)
        
    }
    
    var numCount:String = ""
    {
        didSet{
            inputLabel.text = "\(numCount) ="
        }
    }

    var total:String = ""
    {
        didSet{
            totalLabel.text = total
        }
    }
    
    func buttonHighlight (_ tag: Int)
    {
        ope[1].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[2].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[3].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[4].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        
        if tag == 11{
            ope[1].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if tag == 12{
            ope[2].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if tag == 13{
            ope[3].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if tag == 14{
            ope[4].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if tag != 17{
            p_or_n = false
        }
    }
    
    func buttonHighlightP (_ p:String){
        ope[1].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[2].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[3].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        ope[4].backgroundColor = #colorLiteral(red: 1, green: 0.7215940206, blue: 0.2591413604, alpha: 1)
        
        if p == "+"{
            ope[1].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if p == "-"{
            ope[2].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if p == "x"{
            ope[3].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if p == "/"{
            ope[4].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
    }
    
    func removeZero(_ numS:String) -> String{
        var temS:String = numS
        var isPoint:Bool = false
        for i in (0...temS.count){
            if temS[temS.index(before: temS.endIndex)] == "0" || temS[temS.index(before:temS.endIndex)]  == "."{
                if isPoint == true{
                    break
                }
                if temS[temS.index(before: temS.endIndex)] == "."{
                    isPoint = true
                }
                temS.remove(at: temS.index(before: temS.endIndex))
                
                /*
                if temS.count == 1{
                    break
                }
                 */
            }else{
                return temS
            }
        }
        
        return temS
    }
}
